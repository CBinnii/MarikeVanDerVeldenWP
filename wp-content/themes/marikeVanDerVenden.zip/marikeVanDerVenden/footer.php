        <footer class="footer">
            <div class="container">
                <div class="partner">
                    <p>© 2023 - Marike van der Velden - All rights reserved</p>

                    <p>Gerealiseerd door <a href="http://webwow.nl" target="_blank">WebWoW</a> </p>
                </div>
            </div>
        </footer>

		<?php wp_footer(); ?>
        <!-- Bootstrap JS -->
        <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/bootstrap.bundle.min.js"></script>
        <!-- App JS -->
        <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/app.js"></script>
    </body>
</html>